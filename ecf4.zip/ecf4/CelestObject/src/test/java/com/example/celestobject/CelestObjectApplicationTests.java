package com.example.celestobject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CelestObjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
