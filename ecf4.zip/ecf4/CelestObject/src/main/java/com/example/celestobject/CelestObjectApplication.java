package com.example.celestobject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CelestObjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(CelestObjectApplication.class, args);
    }

}
