package com.example.celestobservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CelestObservationApplication {

    public static void main(String[] args) {
        SpringApplication.run(CelestObservationApplication.class, args);
    }

}
