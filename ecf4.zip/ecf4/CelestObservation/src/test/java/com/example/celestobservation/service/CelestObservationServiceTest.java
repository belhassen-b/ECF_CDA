package com.example.celestobservation.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CelestObservationServiceTest {

    @Test
    void createCelestObservation() {


    }

    @Test
    void getCelestObservationById() {
    }

    @Test
    void getCelestObservationByUserId() {
    }

    @Test
    void getCelestObservationByDate() {
    }
}