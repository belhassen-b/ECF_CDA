package com.example.celestobservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CelestObservationApplicationTests {

    @Test
    void contextLoads() {
    }

}
