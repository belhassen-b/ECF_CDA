package com.example.authentication.security;

public class SecurityConstants {
    public static final long JWT_EXPIRATION = 1000000000;
}
